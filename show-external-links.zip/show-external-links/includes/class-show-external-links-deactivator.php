<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://web-svb.github.io/sel.github.io
 * @since      1.0.0
 *
 * @package    Show_External_Links
 * @subpackage Show_External_Links/includes
 */

class Show_External_Links_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
